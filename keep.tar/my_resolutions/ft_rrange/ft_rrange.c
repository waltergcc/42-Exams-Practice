#include <stdio.h>
#include <stdlib.h>

int	absoluteNumber(int n)
{
	if (n < 0)
		return (-n);
	else
		return (n);
}

int     *ft_rrange(int start, int end)
{
	int size = absoluteNumber(start - end) + 1;
	int *range = (int *)malloc(sizeof(int) * size);
	if (!range)
		return (NULL);

	int i = 0;
	while (i < size)
	{
		if (end <= start)
			range[i] = end + i;
		else if (end > start)
			range[i] = end - i;
		i++;
	}
	return (range);
}
/* 
int	main(void)
{
	int	start[5] = {1, -1, 0, 0, 3};
	int	end[5] = {3, 2, 0, -3, 8};

	for (int i = 0; i < 5; i++)
	{
		int *range = ft_rrange(start[i], end[i]);
		int size = absoluteNumber(start[i] - end[i]) + 1;
		for (int j = 0; j < size; j++)
			printf("%d, ", range[j]);
		free(range);
		printf("\n");
	}
} */